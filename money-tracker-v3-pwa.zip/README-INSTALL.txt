# Money Tracker V3 PWA

## Cara install di Android
1. Upload folder ini ke hosting HTTPS (GitHub Pages, Netlify, Vercel, atau hosting sendiri).
2. Buka URL-nya di Chrome Android.
3. Pilih "Install app" / "Tambahkan ke layar utama".
4. Atau gunakan tombol ⬇ di header aplikasi jika muncul.

## Catatan
- PWA/service worker membutuhkan HTTPS (localhost juga diperbolehkan untuk testing).
- Data transaksi tetap disimpan di localStorage browser.
- Jika domain/URL berubah, data localStorage pada URL lama tidak otomatis ikut pindah.
- Chart.js masih dimuat dari CDN saat koneksi tersedia.
